public class HighscoreModel {
    public String name;
    public Integer score;

    public HighscoreModel(String name, Integer score) {
        this.name = name;
        this.score = score;
    }
}