
public enum Key {
	Up, Down, Left, Right, Enter, Space, Escape
}
